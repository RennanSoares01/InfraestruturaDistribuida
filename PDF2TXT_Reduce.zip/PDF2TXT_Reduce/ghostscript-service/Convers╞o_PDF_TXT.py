from flask import Flask, request, jsonify
import subprocess
import os

app = Flask(__name__)


@app.route('/convert_to_text', methods=['POST'])
def convert_to_text():
    file = request.files['file']
    filename = file.filename
    input_path = f"/tmp/{filename}"
    output_path = f"/tmp/{filename}.txt"
    file.save(input_path)

    subprocess.run(['pdftotext', input_path, output_path])

    # Log operation here with a token

    return jsonify({"message": "Conversion to text completed", "download_link": output_path})


if __name__ == '__main__':
    app.run(host='0.0.0.0')
