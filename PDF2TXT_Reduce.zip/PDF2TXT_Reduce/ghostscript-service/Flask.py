from flask import Flask, request, jsonify
import subprocess
import os

app = Flask(__name__)


@app.route('/reduce_resolution', methods=['POST'])
def reduce_resolution():
    resolution = request.form['resolution']
    file = request.files['file']
    filename = file.filename
    input_path = f"/tmp/{filename}"
    output_path = f"/tmp/reduced_{filename}"
    file.save(input_path)

    # Comando Ghostscript para reduzir a resolução do PDF
    subprocess.run(['gs', '-sDEVICE=pdfwrite', f'-dPDFSETTINGS=/{resolution}',
                    '-dNOPAUSE', '-dBATCH', '-sOutputFile=' + output_path, input_path])

    return jsonify({"message": "Resolution reduced", "download_link": output_path})


if __name__ == '__main__':
    app.run(host='0.0.0.0')

