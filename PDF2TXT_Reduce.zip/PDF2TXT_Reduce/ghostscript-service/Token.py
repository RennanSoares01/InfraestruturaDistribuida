from flask import Flask, request, jsonify
import datetime

app = Flask(__name__)
valid_tokens = {"service1_token", "service2_token"}  # Example tokens


@app.route('/log', methods=['POST'])
def log_operation():
    token = request.headers.get('Authorization')
    if token not in valid_tokens:
        return jsonify({"error": "Unauthorized"}), 401

    data = request.json
    with open('/logs/operations.log', 'a') as log_file:
        log_file.write(f"{datetime.datetime.now()} - {data['operation']} - {data['details']}\n")

    return jsonify({"message": "Log recorded"})


if __name__ == '__main__':
    app.run(host='0.0.0.0')
